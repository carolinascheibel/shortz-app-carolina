const {DataTypes} =  require ('sequelize');
const sequelize = require('../../config/database');

const User = sequelize.define(
    'User', //nome da tabela dentro do BD MySQL
    { // coleção de campos da tabela User
        id: {
            type: DataTypes.INTEGER,
            primaryKey: true,
            autoIncremet: true
        },
        username:{
            type:DataTypes.STRING,
            allowNull: false,
            unique: true
        },
        email : {
            type: DataTypes.STRING,
            allowNull: false,
            unique: true,
            validate : { isEmail: true }
        },
        password:{
            type : DataTypes.STRING,
             allowNull: false
        },
        fullname:{
            type: DataTypes.STRING,
            allowNull:  true
        },
        bio: {
          type:  DataTypes.STRING(255),
          allowNull: true
        }
    }
);

module.exports = User;